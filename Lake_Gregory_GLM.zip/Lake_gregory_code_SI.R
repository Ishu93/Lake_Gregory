cat("\f")
rm(list = ls())


setwd(dirname(rstudioapi::getSourceEditorContext()$path))
setwd('./glake')

list.files()

library(rLakeAnalyzer)
library(GLM3r)
library(glmtools)
library(tidyverse)
library(adagio)
library(ie2misc)
library(hydroGOF)
library(patchwork)

glm_version()


sim_folder <- getwd()
out_file <- file.path(sim_folder, "output","output.nc")
nml_file <- file.path(sim_folder, 'glm3.nml')
glm_template = 'glm3-template.nml' 
field_data <- file.path(sim_folder,"bcs","Landsat_temp.csv")
Irrigation_data <- file.path(sim_folder,"bcs","Irrigation_Temp.csv")


Sys.setenv(TZ='UTC')

GLM3r::run_glm(sim_folder, verbose = T)

# visualize change of surface water temp. over time
surface_temp <- get_var(file = out_file, 
                        var_name = 'temp',reference = 'surface',z_out = 0)


ggplot(surface_temp, aes(DateTime, temp_0)) +
  geom_line() +
  ggtitle('Surface water temperature') +
  xlab(label = '') + ylab(label = 'Temp. (deg C)') +
  theme_minimal()


#average Temperature of simulation
mean(surface_temp$temp_0)

#Calculate RMSE value
temp_rmse <- compare_to_field(nc_file = out_file, 
                              field_file = field_data,
                              metric = 'water.temperature', 
                              as_value = FALSE,) 



print(paste('Total time period (uncalibrated):',round(temp_rmse,2),'deg C RMSE'))

compare_data <- resample_to_field(nc_file = out_file, field_file = field_data, 
                                  var_name = "temp")


compare_irrigation <- resample_to_field(nc_file = out_file, field_file = Irrigation_data,
                                        var_name = "temp")

write.csv(compare_irrigation, file.choose())
write.csv(compare_data, file.choose())
#correlation coefficient
cor(compare_data$Observed_temp, compare_data$Modeled_temp)

#write.csv(compare_data,file.choose())
#Replace Original Values
#file.copy(glm_template, 'glm3.nml', overwrite = TRUE)

#####################################################################################
#Calibration
var = 'temp'         # variable to which we apply the calibration procedure
path = getwd()       # simulation path/folder
nml_file = nml_file  # path of the nml configuration file that you want to calibrate on
glm_file = nml_file # # path of the gml configuration file
# which parameter do you want to calibrate? a sensitivity analysis helps
calib_setup <- data.frame('pars' = as.character(c('sed_temp_peak_doy','sed_temp_peak_doy','sed_temp_peak_doy',
                                                  'ce','Kw','ch','sed_temp_depth',
                                                  'sed_temp_mean','sed_temp_mean','sed_temp_mean',
                                                  'sed_heat_Ksoil')),
                          'lb' = c(60,110,100,
                                   0.0010,0.3,0.0030,0.2,
                                   15,15,15,
                                   1.0),
                          'ub' = c(130,150,140,
                                   0.0035,2.9,0.0050,0.6,
                                   30,25,25,
                                   2.9),
                          'x0' = c(130,120,110,
                                   0.0035,2.9,0.0030,0.2,
                                   15,17,20,
                                   2.9))
print(calib_setup)


glmcmd = NULL        # command to be used, default applies the GLM3r function
# glmcmd = '/Users/robertladwig/Documents/AquaticEcoDynamics_gfort/GLM/glm'        # custom path to executable
# Optional variables
first.attempt = TRUE # if TRUE, deletes all local csv-files that stores the 
#outcome of previous calibration runs
period = get_calib_periods(nml_file, ratio = 0.665) # define a period for the calibration, 
# this supports a split-sample calibration (e.g. calibration and validation period)
# the ratio value is the ratio of calibration period to validation period
print(period)
scaling = TRUE       # scaling of the variables in a space of [0,10]; TRUE for CMA-ES
verbose = TRUE
method = 'CMA-ES'    # optimization method, choose either `CMA-ES` or `Nelder-Mead`
metric = 'RMSE'      # objective function to be minimized, here the root-mean square error
target.fit = 2.0     # refers to a target fit of 2.0 degrees Celsius (stops when RMSE is below that)
target.iter = 2000   # refers to a maximum run of 20 calibration iterations (stops after that many runs)
plotting = TRUE      # if TRUE, script will automatically save the contour plots
output = out_file    # path of the output file
field_file = field_data # path of the field data
conversion.factor = 1 # conversion factor for the output, e.g. 1 for water temp.

calibrate_sim(var = 'temp', path = getwd(), 
              field_file = field_file, 
              nml_file = nml_file, 
              glm_file = glm_file, 
              calib_setup = calib_setup, 
              glmcmd = NULL, first.attempt = TRUE, 
              period = period, 
              scaling = TRUE, method = 'CMA-ES', metric = 'RMSE', 
              target.fit = 2.0, target.iter = 2000, 
              plotting = TRUE, 
              output = output, 
              verbose = FALSE,
              conversion.factor = 1)



# plot heat maps of water temperature
plot_var(nc_file = out_file, var_name = 'temp')


# visualize change of surface water temp. over time
surface_temp <- get_var(file = out_file,
                        var_name = 'temp',reference = 'surface',z_out = 0)


ggplot(surface_temp, aes(DateTime, temp_0)) +
  geom_line() +
  ggtitle('Surface water temperature') +
  xlab(label = '') + ylab(label = 'Temp. (deg C)') +
  theme_minimal()

# Read observed temperature data from CSV file
observed_temp <- read.csv(field_data)

# Convert DateTime column to POSIXct class
observed_temp$datetime <- as.POSIXct(observed_temp$datetime)

ggplot(surface_temp, aes(DateTime, temp_0)) +
  geom_line() +
  geom_point(data = observed_temp, aes(datetime, temp), color = "red") +
  ggtitle('Surface water temperature') +
  xlab(label = '') + ylab(label = 'Temp. (deg C)') +
  theme_minimal()

# Read observed temperature data from Irrigation file
observed_temp_1 <- read.csv(Irrigation_data)

# Convert DateTime column to POSIXct class
observed_temp_1$datetime <- as.POSIXct(observed_temp_1$datetime)

ggplot(surface_temp, aes(DateTime, temp_0)) +
  geom_line() +
  geom_point(data = observed_temp_1, aes(datetime, temp), color = "red4") +
  geom_point(data = observed_temp, aes(datetime, temp), color = "red")+
  ggtitle('Surface water temperature') +
  xlab(label = '') + ylab(label = 'Temp. (deg C)') +
  theme_minimal()


ggplot(surface_temp, aes(DateTime, temp_0)) +
  geom_line() +
  geom_point(data = observed_temp, aes(datetime, temp), color = "red") +
  geom_line(data = observed_temp, aes(datetime, temp), color = "red") + # Add line for observed values
  ggtitle('Surface water temperature') +
  xlab(label = '') + ylab(label = 'Temp. (deg C)') +
  theme_minimal()

# Read observed outflow data from outflow
Out_Flow <- read.csv("bcs/Outflow_Gregory.csv")

# Check the structure of the data frame to confirm column names
str(Out_Flow)

# Convert DateTime column to POSIXct class
Out_Flow$Date <- as.POSIXct(Out_Flow$Date)

# Check the range of dates in both datasets
min_date <- min(c(min(surface_temp$DateTime), min(observed_temp_1$datetime), min(observed_temp$datetime), min(Out_Flow$Date)))
max_date <- max(c(max(surface_temp$DateTime), max(observed_temp_1$datetime), max(observed_temp$datetime), max(Out_Flow$Date)))

# Plot for surface water temperature
temp_plot <- ggplot(surface_temp, aes(DateTime, temp_0)) +
  geom_line() +
  geom_point(data = observed_temp_1, aes(datetime, temp), color = "red4") +
  geom_point(data = observed_temp, aes(datetime, temp), color = "red") +
  ggtitle('Surface water temperature') +
  xlab(label = '') + 
  ylab(label = 'Temp. (deg C)') +
  theme_minimal() +
  xlim(min_date, max_date)

# Plot for outflow data
#outflow_plot <- ggplot(Out_Flow, aes(Date, outflow)) + # Make sure the column name is correct
#  geom_line(color = "blue") +
#  ggtitle('Outflow Variation') +
#  xlab('Date') +
#  ylab('Flow (m3/s)') +
#  theme_minimal() +
#  xlim(min_date, max_date)

# Combine the two plots vertically
#combined_plot <- temp_plot / outflow_plot

# Display the combined plot
#print(combined_plot)


#Assuming you want a moving average over a window size of 5 data points
#moving_avg <- surface_temp %>%
#  mutate(ma_temp_0 = zoo::rollmean(temp_0, k = 10, fill = NA, align = "center"))

#ggplot(surface_temp, aes(DateTime, temp_0)) +
#  geom_line(color = "gray77") + # Plot the original surface_temp line in blue
#  geom_point(data = observed_temp, aes(datetime, temp), color = "red") + # Plot observed temperature points
#  geom_line(data = observed_temp, aes(datetime, temp), color = "red") + # Add line for observed values
#  geom_line(data = moving_avg, aes(DateTime, ma_temp_0), color = "blue") + # Add moving average line
#  ggtitle('Surface water temperature') +
#  xlab(label = '') + ylab(label = 'Temp. (deg C)') +
#  theme_minimal()


